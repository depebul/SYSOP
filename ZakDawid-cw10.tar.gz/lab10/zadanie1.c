#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <stdarg.h>

#define MAX_PATIENTS_IN_HOSPITAL 3
#define MEDICINE_BOX_CAPACITY 6

int waiting_patients = 0, medicines = MEDICINE_BOX_CAPACITY, patients_left = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t doctor_sleep = PTHREAD_COND_INITIALIZER;
pthread_cond_t patient_wait = PTHREAD_COND_INITIALIZER;
pthread_cond_t pharm_wait = PTHREAD_COND_INITIALIZER;

void print_time_msg(const char *fmt, ...)
{
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    printf("[%02d:%02d:%02d] - ", t->tm_hour, t->tm_min, t->tm_sec);
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
}

void *doctor(void *arg)
{
    while (1)
    {
        pthread_mutex_lock(&mutex);
        while (!((waiting_patients == 3 && medicines >= 3) || (medicines < 3)))
        {
            pthread_cond_wait(&doctor_sleep, &mutex);
        }
        if (waiting_patients == 3 && medicines >= 3)
        {
            print_time_msg("Doctor: waking up.\n");
            print_time_msg("Doctor: consulting 3 patients.\n");
            medicines -= 3;
            waiting_patients = 0;
            patients_left -= 3;
            pthread_cond_broadcast(&patient_wait);
            sleep(rand() % 3 + 2);
        }
        else if (medicines < 3)
        {
            print_time_msg("Doctor: accepting medicine delivery.\n");
            medicines = MEDICINE_BOX_CAPACITY;
            pthread_cond_signal(&pharm_wait);
            sleep(rand() % 3 + 1);
        }
        if (patients_left <= 0)
        {
            pthread_mutex_unlock(&mutex);
            break;
        }
        print_time_msg("Doctor: sleeping.\n");
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

void *patient(void *arg)
{
    int id = *(int *)arg;
    while (1)
    {
        int t = rand() % 4 + 2;
        print_time_msg("Patient(%d): Coming in %d s.\n", id, t);
        sleep(t);

        pthread_mutex_lock(&mutex);
        if (waiting_patients >= MAX_PATIENTS_IN_HOSPITAL)
        {
            int walk = rand() % 4 + 2;
            print_time_msg("Patient(%d): Too many, walking %d s.\n", id, walk);
            pthread_mutex_unlock(&mutex);
            sleep(walk);
            continue;
        }
        waiting_patients++;
        print_time_msg("Patient(%d): Waiting (%d).\n", id, waiting_patients);
        if (waiting_patients == 3)
        {
            print_time_msg("Patient(%d): Waking doctor.\n", id);
            pthread_cond_signal(&doctor_sleep);
        }
        while (waiting_patients != 0)
            pthread_cond_wait(&patient_wait, &mutex);
        print_time_msg("Patient(%d): Done.\n", id);
        pthread_mutex_unlock(&mutex);
        break;
    }
    return NULL;
}

void *pharmacist(void *arg)
{
    int id = *(int *)arg;
    while (1)
    {
        int t = rand() % 11 + 5;
        print_time_msg("Pharmacist(%d): Coming in %d s.\n", id, t);
        sleep(t);

        pthread_mutex_lock(&mutex);
        while (medicines == MEDICINE_BOX_CAPACITY)
            pthread_cond_wait(&pharm_wait, &mutex);
        if (medicines < 3)
        {
            print_time_msg("Pharmacist(%d): Waking doctor.\n", id);
            pthread_cond_signal(&doctor_sleep);
            print_time_msg("Pharmacist(%d): Delivering medicines.\n", id);
            pthread_mutex_unlock(&mutex);
            break;
        }
        pthread_mutex_unlock(&mutex);
    }
    print_time_msg("Pharmacist(%d): Finished.\n", id);
    return NULL;
}

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        printf("Usage: %s <patients> <pharmacists>\n", argv[0]);
        return 1;
    }
    srand(time(NULL));
    int n_patients = atoi(argv[1]), n_pharm = atoi(argv[2]);
    patients_left = n_patients;

    pthread_t doc, *patients = malloc(n_patients * sizeof(pthread_t)), *pharms = malloc(n_pharm * sizeof(pthread_t));
    int *pids = malloc(n_patients * sizeof(int)), *phids = malloc(n_pharm * sizeof(int));

    pthread_create(&doc, NULL, doctor, NULL);
    for (int i = 0; i < n_patients; i++)
    {
        pids[i] = i + 1;
        pthread_create(&patients[i], NULL, patient, &pids[i]);
    }
    for (int i = 0; i < n_pharm; i++)
    {
        phids[i] = i + 1;
        pthread_create(&pharms[i], NULL, pharmacist, &phids[i]);
    }
    for (int i = 0; i < n_patients; i++)
        pthread_join(patients[i], NULL);
    pthread_join(doc, NULL);
    for (int i = 0; i < n_pharm; i++)
        pthread_join(pharms[i], NULL);

    free(patients);
    free(pharms);
    free(pids);
    free(phids);
    print_time_msg("Simulation finished.\n");
    return 0;
}